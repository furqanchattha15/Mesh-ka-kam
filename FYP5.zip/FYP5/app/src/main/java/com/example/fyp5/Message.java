package com.example.fyp5;

import org.json.JSONObject;
import java.util.UUID;

public class Message {

    public static final String TYPE_CHAT      = "CHAT";
    public static final String TYPE_HANDSHAKE = "HANDSHAKE";
    public static final String TYPE_IMAGE     = "IMAGE";
    public static final String TYPE_VOICE     = "VOICE";

    public String type;
    public String id;
    public String text;
    public String fileName;
    public long   payloadId;
    public String senderName;
    public String senderEndpointId;
    public String targetEndpointId;
    public int    ttl;
    public boolean isEncrypted;
    public String senderPublicKey;

    public Message(String text, String senderName, String senderEndpointId, String targetEndpointId, int ttl, boolean isEncrypted) {
        this.type             = TYPE_CHAT;
        this.id               = UUID.randomUUID().toString();
        this.text             = text;
        this.fileName         = "";
        this.payloadId        = 0;
        this.senderName       = senderName;
        this.senderEndpointId = senderEndpointId;
        this.targetEndpointId = targetEndpointId;
        this.ttl              = ttl;
        this.isEncrypted      = isEncrypted;
        this.senderPublicKey  = "";
    }

    public Message(String type, String fileName, long payloadId, String senderName, String senderEndpointId, String targetEndpointId, int ttl, boolean isEncrypted) {
        this.type             = type;
        this.id               = UUID.randomUUID().toString();
        this.text             = "";
        this.fileName         = fileName;
        this.payloadId        = payloadId;
        this.senderName       = senderName;
        this.senderEndpointId = senderEndpointId;
        this.targetEndpointId = targetEndpointId;
        this.ttl              = ttl;
        this.isEncrypted      = isEncrypted;
        this.senderPublicKey  = "";
    }

    public Message(String senderName, String senderEndpointId, String senderPublicKey) {
        this.type             = TYPE_HANDSHAKE;
        this.id               = UUID.randomUUID().toString();
        this.text             = "";
        this.fileName         = "";
        this.payloadId        = 0;
        this.senderName       = senderName;
        this.senderEndpointId = senderEndpointId;
        this.targetEndpointId = "ALL";
        this.ttl              = 5;
        this.isEncrypted      = false;
        this.senderPublicKey  = senderPublicKey;
    }

    public JSONObject toJson() throws Exception {
        JSONObject obj = new JSONObject();
        obj.put("type",             type);
        obj.put("id",               id);
        obj.put("text",             text);
        obj.put("fileName",         fileName);
        obj.put("payloadId",        payloadId);
        obj.put("senderName",       senderName);
        obj.put("senderEndpointId", senderEndpointId);
        obj.put("targetEndpointId", targetEndpointId);
        obj.put("ttl",              ttl);
        obj.put("isEncrypted",      isEncrypted);
        obj.put("senderPublicKey",  senderPublicKey);
        return obj;
    }

    public static Message fromJson(String json) throws Exception {
        JSONObject obj  = new JSONObject(json);
        String     type = obj.optString("type", TYPE_CHAT);
        Message    msg;

        switch (type) {
            case TYPE_HANDSHAKE:
                msg = new Message(obj.getString("senderName"), obj.getString("senderEndpointId"), obj.optString("senderPublicKey", ""));
                break;
            case TYPE_IMAGE:
            case TYPE_VOICE:
                msg = new Message(
                        type,
                        obj.optString("fileName", "file"),
                        obj.optLong("payloadId", 0),
                        obj.getString("senderName"),
                        obj.getString("senderEndpointId"),
                        obj.getString("targetEndpointId"),
                        obj.getInt("ttl"),
                        obj.optBoolean("isEncrypted", true)
                );
                break;
            default:
                msg = new Message(
                        obj.getString("text"),
                        obj.getString("senderName"),
                        obj.getString("senderEndpointId"),
                        obj.getString("targetEndpointId"),
                        obj.getInt("ttl"),
                        obj.optBoolean("isEncrypted", true)
                );
                break;
        }

        msg.id              = obj.getString("id");
        msg.type            = type;
        msg.senderPublicKey = obj.optString("senderPublicKey", "");
        return msg;
    }
}