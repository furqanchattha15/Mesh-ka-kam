package com.example.fyp5;

import android.util.Base64;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoUtils {

    public static class EncryptedPayloadBundle {
        public byte[] encryptedData;
        public byte[] encryptedAesKey;
        public byte[] signature;
        public byte[] iv;

        public EncryptedPayloadBundle(byte[] encryptedData, byte[] encryptedAesKey, byte[] signature, byte[] iv) {
            this.encryptedData = encryptedData;
            this.encryptedAesKey = encryptedAesKey;
            this.signature = signature;
            this.iv = iv;
        }

        public String toJsonString() throws Exception {
            JSONObject obj = new JSONObject();
            obj.put("data", Base64.encodeToString(encryptedData, Base64.NO_WRAP));
            obj.put("key", Base64.encodeToString(encryptedAesKey, Base64.NO_WRAP));
            obj.put("sig", Base64.encodeToString(signature, Base64.NO_WRAP));
            obj.put("iv", Base64.encodeToString(iv, Base64.NO_WRAP));
            return obj.toString();
        }

        public static EncryptedPayloadBundle fromJsonString(String json) throws Exception {
            JSONObject obj = new JSONObject(json);
            byte[] data = Base64.decode(obj.getString("data"), Base64.NO_WRAP);
            byte[] key = Base64.decode(obj.getString("key"), Base64.NO_WRAP);
            byte[] sig = Base64.decode(obj.getString("sig"), Base64.NO_WRAP);
            byte[] iv = Base64.decode(obj.getString("iv"), Base64.NO_WRAP);
            return new EncryptedPayloadBundle(data, key, sig, iv);
        }
    }

    public static KeyPair generateRsaKeyPair() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        return kpg.generateKeyPair();
    }

    public static String publicKeyToString(PublicKey key) {
        return Base64.encodeToString(key.getEncoded(), Base64.NO_WRAP);
    }

    public static PublicKey stringToPublicKey(String keyStr) throws Exception {
        byte[] bytes = Base64.decode(keyStr, Base64.NO_WRAP);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(bytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePublic(spec);
    }

    public static EncryptedPayloadBundle encryptData(byte[] rawData, PublicKey targetPublicKey, PrivateKey senderPrivateKey) throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(256);
        SecretKey aesKey = keyGen.generateKey();

        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);

        Cipher aesCipher = Cipher.getInstance("AES/GCM/NoPadding");
        aesCipher.init(Cipher.ENCRYPT_MODE, aesKey, new GCMParameterSpec(128, iv));
        byte[] encryptedData = aesCipher.doFinal(rawData);

        Cipher rsaCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        rsaCipher.init(Cipher.ENCRYPT_MODE, targetPublicKey);
        byte[] encryptedAesKey = rsaCipher.doFinal(aesKey.getEncoded());

        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(senderPrivateKey);
        sig.update(encryptedData);
        byte[] signature = sig.sign();

        return new EncryptedPayloadBundle(encryptedData, encryptedAesKey, signature, iv);
    }

    public static byte[] decryptData(EncryptedPayloadBundle bundle, PrivateKey recipientPrivateKey, PublicKey senderPublicKey) throws Exception {
        Cipher rsaCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        rsaCipher.init(Cipher.DECRYPT_MODE, recipientPrivateKey);
        byte[] rawAesKey = rsaCipher.doFinal(bundle.encryptedAesKey);

        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initVerify(senderPublicKey);
        sig.update(bundle.encryptedData);
        if (!sig.verify(bundle.signature)) {
            throw new SecurityException("Signature verification failed! Message tampered or corrupt.");
        }

        SecretKey aesKey = new SecretKeySpec(rawAesKey, "AES");
        Cipher aesCipher = Cipher.getInstance("AES/GCM/NoPadding");
        aesCipher.init(Cipher.DECRYPT_MODE, aesKey, new GCMParameterSpec(128, bundle.iv));
        return aesCipher.doFinal(bundle.encryptedData);
    }

    public static void encryptFile(File srcFile, File destFile, PublicKey targetPubKey, PrivateKey senderPrivKey) throws Exception {
        byte[] fileBytes = readFileToBytes(srcFile);
        EncryptedPayloadBundle bundle = encryptData(fileBytes, targetPubKey, senderPrivKey);
        String bundleJson = bundle.toJsonString();
        FileOutputStream fos = new FileOutputStream(destFile);
        fos.write(bundleJson.getBytes("UTF-8"));
        fos.close();
    }

    public static void decryptFile(File encFile, File destFile, PrivateKey recPrivKey, PublicKey senderPubKey) throws Exception {
        byte[] encFileBytes = readFileToBytes(encFile);
        String bundleJson = new String(encFileBytes, "UTF-8");
        EncryptedPayloadBundle bundle = EncryptedPayloadBundle.fromJsonString(bundleJson);
        byte[] decryptedBytes = decryptData(bundle, recPrivKey, senderPubKey);

        FileOutputStream fos = new FileOutputStream(destFile);
        fos.write(decryptedBytes);
        fos.close();
    }

    private static byte[] readFileToBytes(File file) throws Exception {
        FileInputStream fis = new FileInputStream(file);
        byte[] data = new byte[(int) file.length()];
        int read = fis.read(data);
        fis.close();
        return data;
    }
}