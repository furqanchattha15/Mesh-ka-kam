package com.example.fyp5;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.MediaStore;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.KeyPair;
import java.security.PublicKey;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String SERVICE_ID = "com.example.fyp5.mesh";
    private static final int PERMISSION_REQUEST_CODE = 100;

    private ConnectionsClient client;
    private String myUniqueId;
    private String myName;

    // Cryptographic Keys
    private KeyPair myKeyPair;
    private final Map<String, PublicKey> peerPublicKeys = Collections.synchronizedMap(new HashMap<>());

    private final Map<String, String> connectedPeers = Collections.synchronizedMap(new HashMap<>());
    private final Map<String, String> knownDevices = Collections.synchronizedMap(new HashMap<>());
    private final Map<String, String> uniqueToEndpoint = Collections.synchronizedMap(new HashMap<>());

    private final Map<Long, Payload> incomingPayloads = Collections.synchronizedMap(new HashMap<>());
    private final Map<Long, Message> incomingFileMeta = Collections.synchronizedMap(new HashMap<>());

    private final Set<String> seenMessages = Collections.synchronizedSet(new HashSet<>());
    private final Set<String> selectedTargets = Collections.synchronizedSet(new HashSet<>());

    // Recording & Media
    private MediaRecorder mediaRecorder;
    private File voiceFile;
    private boolean isRecording = false;
    private File cameraImageFile;

    // Views
    private EditText input;
    private LinearLayout logContainer;
    private LinearLayout deviceListLayout;
    private ScrollView logScrollView;
    private ImageButton btnVoice;

    private boolean isServiceBound = false;
    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            isServiceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isServiceBound = false;
        }
    };

    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) sendImageFromUri(uri);
                }
            });

    private final ActivityResultLauncher<Intent> cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && cameraImageFile != null && cameraImageFile.exists()) {
                    sendFile(cameraImageFile, Message.TYPE_IMAGE, cameraImageFile.getName());
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myUniqueId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        myName = Build.MODEL + "#" + myUniqueId;

        // Generate Device RSA KeyPair
        try {
            myKeyPair = CryptoUtils.generateRsaKeyPair();
        } catch (Exception e) {
            e.printStackTrace();
        }

        input = findViewById(R.id.input);
        logContainer = findViewById(R.id.logContainer);
        deviceListLayout = findViewById(R.id.deviceListLayout);
        logScrollView = findViewById(R.id.logScrollView);
        btnVoice = findViewById(R.id.btnVoice);

        findViewById(R.id.sendBtn).setOnClickListener(v -> sendMessage());
        findViewById(R.id.btnGallery).setOnClickListener(v -> openGallery());
        findViewById(R.id.btnCamera).setOnClickListener(v -> openCamera());
        btnVoice.setOnClickListener(v -> toggleVoiceRecording());

        client = Nearby.getConnectionsClient(this);

        log("=== MeshChat Secure (Always Encrypted) ===");
        log("Device Name: " + myName);
        log("Device ID  : " + myUniqueId);
        log("=========================================");

        startForegroundMeshService();
        requestPermissions();
    }

    private void startForegroundMeshService() {
        Intent serviceIntent = new Intent(this, MeshService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, serviceIntent);
        } else {
            startService(serviceIntent);
        }
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isServiceBound) {
            unbindService(serviceConnection);
            isServiceBound = false;
        }
    }

    private void requestPermissions() {
        List<String> permissions = new ArrayList<>();
        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        permissions.add(Manifest.permission.CAMERA);
        permissions.add(Manifest.permission.RECORD_AUDIO);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN);
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
            permissions.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES);
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES);
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN);
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
            permissions.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        List<String> listPermissionsNeeded = new ArrayList<>();
        for (String p : permissions) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(p);
            }
        }

        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[0]), PERMISSION_REQUEST_CODE);
        } else {
            startAdvertisingAndDiscovery();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                startAdvertisingAndDiscovery();
            } else {
                Toast.makeText(this, "Permissions required for Mesh Chat", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void startAdvertisingAndDiscovery() {
        client.stopAdvertising();
        client.startAdvertising(myName, SERVICE_ID, connectionLifecycleCallback,
                        new AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
                .addOnSuccessListener(u -> log("📡 Advertising node..."))
                .addOnFailureListener(e -> log("✗ Adv Error: " + e.getMessage()));

        client.stopDiscovery();
        client.startDiscovery(SERVICE_ID, endpointDiscoveryCallback,
                        new DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
                .addOnSuccessListener(u -> log("🔍 Discovering peers..."))
                .addOnFailureListener(e -> log("✗ Disc Error: " + e.getMessage()));
    }

    private final EndpointDiscoveryCallback endpointDiscoveryCallback = new EndpointDiscoveryCallback() {
        @Override
        public void onEndpointFound(String endpointId, DiscoveredEndpointInfo info) {
            if (connectedPeers.containsKey(endpointId)) return;
            log("📶 Found node: " + info.getEndpointName());
            client.requestConnection(myName, endpointId, connectionLifecycleCallback);
        }

        @Override
        public void onEndpointLost(String id) {
            log("📴 Lost node: " + id);
        }
    };

    private final ConnectionLifecycleCallback connectionLifecycleCallback = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String endpointId, ConnectionInfo info) {
            client.acceptConnection(endpointId, payloadCallback);
        }

        @Override
        public void onConnectionResult(String endpointId, ConnectionResolution result) {
            if (result.getStatus().isSuccess()) {
                String name = knownDevices.getOrDefault(endpointId, "Device_" + endpointId);
                connectedPeers.put(endpointId, name);
                log("✅ Connected: " + name);
                runOnUiThread(() -> refreshDeviceList());
                sendHandshake(endpointId);
            }
        }

        @Override
        public void onDisconnected(String endpointId) {
            String name = connectedPeers.remove(endpointId);
            log("❌ Disconnected: " + (name != null ? name : endpointId));
            runOnUiThread(() -> refreshDeviceList());
        }
    };

    private void sendHandshake(String toEndpointId) {
        try {
            String pubKeyStr = CryptoUtils.publicKeyToString(myKeyPair.getPublic());
            Message hs = new Message(myName, myUniqueId, pubKeyStr);
            seenMessages.add(hs.id);
            client.sendPayload(toEndpointId, Payload.fromBytes(hs.toJson().toString().getBytes()));
        } catch (Exception e) {
            log("✗ Handshake Error: " + e.getMessage());
        }
    }

    private final PayloadCallback payloadCallback = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String fromEndpointId, Payload payload) {
            if (payload.getType() == Payload.Type.BYTES) {
                try {
                    String json = new String(payload.asBytes());
                    Message msg = Message.fromJson(json);

                    if (seenMessages.contains(msg.id)) return;
                    seenMessages.add(msg.id);

                    switch (msg.type) {
                        case Message.TYPE_HANDSHAKE:
                            knownDevices.put(msg.senderEndpointId, msg.senderName);
                            uniqueToEndpoint.put(msg.senderEndpointId, fromEndpointId);
                            if (!msg.senderPublicKey.isEmpty()) {
                                peerPublicKeys.put(msg.senderEndpointId, CryptoUtils.stringToPublicKey(msg.senderPublicKey));
                            }
                            log("🔑 Registered key for device: " + msg.senderName);
                            runOnUiThread(() -> refreshDeviceList());
                            if (msg.ttl > 0) {
                                msg.ttl--;
                                forwardBytes(msg, fromEndpointId);
                            }
                            break;

                        case Message.TYPE_CHAT:
                            if (myUniqueId.equals(msg.targetEndpointId)) {
                                runOnUiThread(() -> renderTextMessage(msg));
                            } else if (msg.ttl > 0) {
                                msg.ttl--;
                                forwardBytes(msg, fromEndpointId);
                            }
                            break;

                        case Message.TYPE_IMAGE:
                        case Message.TYPE_VOICE:
                            incomingFileMeta.put(msg.payloadId, msg);
                            if (!myUniqueId.equals(msg.targetEndpointId) && msg.ttl > 0) {
                                msg.ttl--;
                                forwardBytes(msg, fromEndpointId);
                            }
                            break;
                    }
                } catch (Exception e) {
                    log("✗ Payload Parsing Error: " + e.getMessage());
                }
            } else if (payload.getType() == Payload.Type.FILE) {
                incomingPayloads.put(payload.getId(), payload);
            }
        }

        @Override
        public void onPayloadTransferUpdate(String endpointId, PayloadTransferUpdate update) {
            long pid = update.getPayloadId();
            if (update.getStatus() == PayloadTransferUpdate.Status.SUCCESS) {
                Message meta = incomingFileMeta.remove(pid);
                Payload filePayload = incomingPayloads.remove(pid);

                if (meta == null || filePayload == null) return;

                if (myUniqueId.equals(meta.targetEndpointId)) {
                    try {
                        File srcFile = filePayload.asFile().asJavaFile();
                        if (srcFile != null && srcFile.exists()) {
                            String ext = Message.TYPE_IMAGE.equals(meta.type) ? ".jpg" : ".m4a";
                            File destFile = createDestFile(ext);
                            copyFile(srcFile, destFile);
                            runOnUiThread(() -> renderMediaMessage(destFile, meta));
                        }
                    } catch (Exception e) {
                        log("✗ Process Received File Error: " + e.getMessage());
                    }
                }
            }
        }
    };

    // ================= Automatic Receiver Decryption & UI Renderers =================

    private void renderTextMessage(Message msg) {
        LinearLayout card = createMessageCardBase();

        TextView header = new TextView(this);
        header.setText("💬 " + msg.senderName);
        header.setTypeface(null, Typeface.BOLD);
        card.addView(header);

        TextView body = new TextView(this);

        try {
            PublicKey senderPubKey = peerPublicKeys.get(msg.senderEndpointId);
            if (senderPubKey == null) {
                body.setText("⚠️ Public key missing - Cannot decrypt message!");
            } else {
                // Auto Decrypt Text Message
                CryptoUtils.EncryptedPayloadBundle bundle = CryptoUtils.EncryptedPayloadBundle.fromJsonString(msg.text);
                byte[] decryptedBytes = CryptoUtils.decryptData(bundle, myKeyPair.getPrivate(), senderPubKey);
                String plainText = new String(decryptedBytes, "UTF-8");
                body.setText(plainText);
            }
        } catch (Exception e) {
            body.setText("⚠️ Decryption Failed: Intended for another target.");
        }

        card.addView(body);
        logContainer.addView(card);
        logScrollView.post(() -> logScrollView.fullScroll(View.FOCUS_DOWN));
    }

    private void renderMediaMessage(File encryptedFile, Message meta) {
        LinearLayout card = createMessageCardBase();

        TextView header = new TextView(this);
        header.setText(meta.type + " from " + meta.senderName);
        header.setTypeface(null, Typeface.BOLD);
        card.addView(header);

        try {
            PublicKey senderPubKey = peerPublicKeys.get(meta.senderEndpointId);
            if (senderPubKey == null) {
                Toast.makeText(this, "Sender public key unavailable!", Toast.LENGTH_SHORT).show();
                return;
            }

            String ext = Message.TYPE_IMAGE.equals(meta.type) ? ".jpg" : ".m4a";
            File decryptedFile = createDestFile("_dec" + ext);

            // Auto Decrypt Media File
            CryptoUtils.decryptFile(encryptedFile, decryptedFile, myKeyPair.getPrivate(), senderPubKey);

            if (Message.TYPE_IMAGE.equals(meta.type)) {
                attachImageViewToCard(card, decryptedFile);
            } else {
                attachVoicePlayerToCard(card, decryptedFile);
            }
        } catch (Exception e) {
            TextView errorText = new TextView(this);
            errorText.setText("⚠️ Decryption Failed: Unable to read encrypted file.");
            card.addView(errorText);
        }

        logContainer.addView(card);
        logScrollView.post(() -> logScrollView.fullScroll(View.FOCUS_DOWN));
    }

    private LinearLayout createMessageCardBase() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 16, 20, 16);
        card.setBackgroundColor(0xFFEFEFEF);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 8, 0, 8);
        card.setLayoutParams(params);
        return card;
    }

    private void attachImageViewToCard(LinearLayout card, File imgFile) {
        ImageView iv = new ImageView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 450);
        iv.setLayoutParams(lp);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setImageBitmap(BitmapFactory.decodeFile(imgFile.getAbsolutePath()));
        card.addView(iv);
    }

    private void attachVoicePlayerToCard(LinearLayout card, File audioFile) {
        ImageButton btnPlay = new ImageButton(this);
        btnPlay.setImageResource(android.R.drawable.ic_media_play);

        MediaPlayer mp = new MediaPlayer();
        try {
            mp.setDataSource(audioFile.getAbsolutePath());
            mp.prepare();
        } catch (Exception ignored) {}

        btnPlay.setOnClickListener(v -> {
            if (mp.isPlaying()) {
                mp.pause();
                btnPlay.setImageResource(android.R.drawable.ic_media_play);
            } else {
                mp.start();
                btnPlay.setImageResource(android.R.drawable.ic_media_pause);
            }
        });
        card.addView(btnPlay);
    }

    // ================= Mandatory Always-Encrypted Message Processing =================

    private void sendMessage() {
        String text = input.getText().toString().trim();
        if (text.isEmpty() || selectedTargets.isEmpty()) {
            Toast.makeText(this, "Select target device and enter text", Toast.LENGTH_SHORT).show();
            return;
        }

        for (String targetUid : selectedTargets) {
            try {
                PublicKey targetPubKey = peerPublicKeys.get(targetUid);
                if (targetPubKey == null) {
                    Toast.makeText(this, "Target public key not received yet!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Mandatory Hybrid Encryption (AES-GCM + RSA)
                CryptoUtils.EncryptedPayloadBundle bundle = CryptoUtils.encryptData(text.getBytes("UTF-8"), targetPubKey, myKeyPair.getPrivate());
                String payloadText = bundle.toJsonString();

                Message msg = new Message(payloadText, myName, myUniqueId, targetUid, 5, true);
                seenMessages.add(msg.id);
                Payload p = Payload.fromBytes(msg.toJson().toString().getBytes());

                for (String ep : connectedPeers.keySet()) {
                    client.sendPayload(ep, p);
                }
                log("🔒 Encrypted Message -> " + knownDevices.get(targetUid));
            } catch (Exception e) {
                log("✗ Send Error: " + e.getMessage());
            }
        }
        input.setText("");
    }

    private void sendFile(File originalFile, String type, String fileName) {
        if (selectedTargets.isEmpty()) return;

        for (String targetUid : selectedTargets) {
            try {
                PublicKey targetPubKey = peerPublicKeys.get(targetUid);
                if (targetPubKey == null) {
                    Toast.makeText(this, "Target key missing!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Mandatory File Encryption
                File encFile = createDestFile("_enc.tmp");
                CryptoUtils.encryptFile(originalFile, encFile, targetPubKey, myKeyPair.getPrivate());

                Payload filePayload = Payload.fromFile(encFile);
                long pid = filePayload.getId();

                Message meta = new Message(type, fileName, pid, myName, myUniqueId, targetUid, 5, true);
                seenMessages.add(meta.id);

                Payload metaPayload = Payload.fromBytes(meta.toJson().toString().getBytes());

                for (String ep : connectedPeers.keySet()) {
                    client.sendPayload(ep, metaPayload);
                    client.sendPayload(ep, filePayload);
                }
                log("🔒 Encrypted " + type + " -> " + knownDevices.get(targetUid));
            } catch (Exception e) {
                log("✗ Send File Error: " + e.getMessage());
            }
        }
    }

    private void forwardBytes(Message msg, String fromEndpointId) {
        try {
            Payload p = Payload.fromBytes(msg.toJson().toString().getBytes());
            for (String ep : connectedPeers.keySet()) {
                if (!ep.equals(fromEndpointId)) {
                    client.sendPayload(ep, p);
                }
            }
        } catch (Exception e) {
            log("✗ Relay Error: " + e.getMessage());
        }
    }

    // ================= Media Capture Handlers =================

    private void openGallery() {
        if (selectedTargets.isEmpty()) {
            Toast.makeText(this, "Select a target device first", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        i.setType("image/*");
        galleryLauncher.launch(i);
    }

    private void openCamera() {
        if (selectedTargets.isEmpty()) {
            Toast.makeText(this, "Select a target device first", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            cameraImageFile = new File(getCacheDir(), "CAM_" + ts + ".jpg");
            Uri photoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", cameraImageFile);

            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            cameraLauncher.launch(i);
        } catch (Exception e) {
            log("✗ Camera Error: " + e.getMessage());
        }
    }

    private void toggleVoiceRecording() {
        if (!isRecording) startVoiceRecording();
        else stopVoiceRecording(true);
    }

    private void startVoiceRecording() {
        if (selectedTargets.isEmpty()) {
            Toast.makeText(this, "Select a target device first", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            voiceFile = new File(getCacheDir(), "VOICE_" + ts + ".m4a");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                mediaRecorder = new MediaRecorder(this);
            } else {
                mediaRecorder = new MediaRecorder();
            }

            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mediaRecorder.setOutputFile(voiceFile.getAbsolutePath());
            mediaRecorder.prepare();
            mediaRecorder.start();

            isRecording = true;
            btnVoice.setImageResource(android.R.drawable.ic_media_pause);
            log("🎙 Recording audio...");
        } catch (Exception e) {
            log("✗ Voice Rec Error: " + e.getMessage());
        }
    }

    private void stopVoiceRecording(boolean send) {
        try {
            if (mediaRecorder != null) {
                mediaRecorder.stop();
                mediaRecorder.release();
                mediaRecorder = null;
            }
            isRecording = false;
            btnVoice.setImageResource(android.R.drawable.ic_btn_speak_now);

            if (send && voiceFile != null && voiceFile.exists()) {
                sendFile(voiceFile, Message.TYPE_VOICE, voiceFile.getName());
            }
        } catch (Exception e) {
            log("✗ Voice Stop Error: " + e.getMessage());
        }
    }

    private void sendImageFromUri(Uri uri) {
        try {
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            File temp = new File(getCacheDir(), "IMG_" + ts + ".jpg");
            InputStream in = getContentResolver().openInputStream(uri);
            FileOutputStream out = new FileOutputStream(temp);
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            in.close();
            out.close();

            sendFile(temp, Message.TYPE_IMAGE, temp.getName());
        } catch (Exception e) {
            log("✗ Gallery Send Error: " + e.getMessage());
        }
    }

    // ================= Helpers & Dynamic UI Updates =================

    private void refreshDeviceList() {
        deviceListLayout.removeAllViews();
        for (Map.Entry<String, String> e : knownDevices.entrySet()) {
            String uid = e.getKey();
            String name = e.getValue();
            if (uid.equals(myUniqueId)) continue;

            CheckBox cb = new CheckBox(this);
            cb.setText("📡 " + name);
            cb.setChecked(selectedTargets.contains(uid));
            cb.setOnCheckedChangeListener((btn, checked) -> {
                if (checked) selectedTargets.add(uid);
                else selectedTargets.remove(uid);
            });
            deviceListLayout.addView(cb);
        }
    }

    private File createDestFile(String ext) {
        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.getDefault()).format(new Date());
        return new File(getCacheDir(), "recv_" + ts + ext);
    }

    private void copyFile(File src, File dst) throws Exception {
        FileInputStream in = new FileInputStream(src);
        FileOutputStream out = new FileOutputStream(dst);
        byte[] buf = new byte[8192];
        int len;
        while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
        in.close();
        out.close();
    }

    private void log(String text) {
        runOnUiThread(() -> {
            TextView tv = new TextView(this);
            tv.setText(text);
            tv.setTextSize(12f);
            tv.setTypeface(Typeface.MONOSPACE);
            logContainer.addView(tv);
            logScrollView.post(() -> logScrollView.fullScroll(View.FOCUS_DOWN));
        });
    }
}